$(document).ready( function() {

	$("#token_verify").on('submit', function(e) {
		e.preventDefault();
        $(".juni_spin_verify_code").show();
		var verifycode    = $("#verifycode").val();

		 var settings = {
          "url": "https://polledapp.herokuapp.com/api/register/verify",
          "method": "POST",
          "timeout": 0,
          "data": {
            "verifycode": verifycode
          }
        };
        $.ajax(settings).done(function (response) {
          if (response) {
            $(".juni_spin_verify_code").hide();

            if (response.message == "Account is verified"){
                localStorage.setItem('token', response.token);
                location.replace("../../frontend/PrimedPoll-FrontEnd/completeRegistration.html"); 
            }else if(response.message == "Account is already verified"){
                $("#reg_success").html("Account verified already, try loging.");
                $("#reg_success").css('color', 'red');
            }else{
                $("#reg_success").html("Verificaion Code does not match.");
                $("#reg_success").css('color', 'red');
                $("#verifycode").css('border', '1px solid red');
            }
          }        
        }).fail( function(err) {
        	if (err) {
        		if (err.status === 422) {
        			if (err.responseJSON.verifycode) {
        				$("#juni_err_verifytoken").html(err.responseJSON.verifycode[0]);
        				$("#verifycode").addClass('err_signup_input');
                        $('#signup-form')[0].reset();
                        $(".juni_spin_verify_code").hide();
        			}
        			
        		}
        	}
        	
        });
	});
});


