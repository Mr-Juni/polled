# PrimedPoll-FrontEnd

## This is the PrimedPoll frontEnd page Project

> This is the Primedsoft Organization Poll project, **Zaratti** and **Emma** worked on the frontEnd part of the project
where users can register, login, complete registration and by happenstance where a user may be unable to remember their password,
there is a password recovery page available.


# Authors

- Zaratti   *FrontEnd Web Developer*
- Emma    *FrontEnd Web Developer*
